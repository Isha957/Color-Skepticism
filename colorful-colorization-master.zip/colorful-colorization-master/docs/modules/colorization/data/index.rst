image_file_or_directory
=======================
.. automodule:: colorization.data.image_file_or_directory
   :members:

tiny_image_net
==============
.. automodule:: colorization.data.tiny_image_net
   :members:
